var class_air_quality_controller =
[
    [ "sendAirQualityEvent", "class_air_quality_controller.html#a3836e4dca79c1563fcdae880bb368323", null ]
];